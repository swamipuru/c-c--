int doubleNumber(int n){
 return 2 * n;
}
