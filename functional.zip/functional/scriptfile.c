1. gcc testFunction.c
2. ./a.out factorial.c
3. gcc final.c
4. ./a.out
